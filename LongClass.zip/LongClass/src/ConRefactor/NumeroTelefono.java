/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConRefactor;

/**
 *
 * @author Chris
 */
public class NumeroTelefono {
    String CodigoAreaOficina;
    String numeroOficina;

    public NumeroTelefono(String CodigoAreaOficina, String numeroOficina) {
        this.CodigoAreaOficina = CodigoAreaOficina;
        this.numeroOficina = numeroOficina;
    }

    public String getCodigoAreaOficina() {
        return CodigoAreaOficina;
    }

    public void setCodigoAreaOficina(String CodigoAreaOficina) {
        this.CodigoAreaOficina = CodigoAreaOficina;
    }

    public String getNumeroOficina() {
        return numeroOficina;
    }

    public void setNumeroOficina(String numeroOficina) {
        this.numeroOficina = numeroOficina;
    }
    
    
}
