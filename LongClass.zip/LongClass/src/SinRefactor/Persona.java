/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SinRefactor;

/**
 *
 * @author Chris
 */
public class Persona {
    String nombre;
    String codigoAreaOficina;
    String numeroOficina;

    public Persona(String nombre, String codigoAreaOficina, String numeroOficina) {
        this.nombre = nombre;
        this.codigoAreaOficina = codigoAreaOficina;
        this.numeroOficina = numeroOficina;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigoAreaOficina() {
        return codigoAreaOficina;
    }

    public void setCodigoAreaOficina(String CodigoAreaOficina) {
        this.codigoAreaOficina = CodigoAreaOficina;
    }

    public String getNumeroOficina() {
        return numeroOficina;
    }

    public void setNumeroOficina(String NumeroOficina) {
        this.numeroOficina = NumeroOficina;
    }
    
    
    
    
           
    
}
